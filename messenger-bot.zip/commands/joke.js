exports.run = (senderId, args, send) => {
  const jokes = [
    "Why did the bot cross the road? To send a message!",
    "I'm a bot — my punchlines are pre-trained!",
    "Why do robots never panic? Because they have nerves of steel!"
  ];
  const joke = jokes[Math.floor(Math.random() * jokes.length)];
  send(senderId, joke);
};
