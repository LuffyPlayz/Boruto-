exports.run = (senderId, args, send) => {
  const facts = [
    "Messenger bots can reply in milliseconds!",
    "Node.js is fast and scalable for bots.",
    "You can create 10,000+ commands easily with modular design!"
  ];
  const fact = facts[Math.floor(Math.random() * facts.length)];
  send(senderId, fact);
};
